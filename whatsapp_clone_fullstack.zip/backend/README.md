# Backend (Express + Mongoose)
## Quick start
- Copy `.env.example` to `.env` and set MONGO_URI
- Install: `npm install`
- Start: `npm run dev` (requires nodemon) or `npm start`
- Process sample payloads: place JSON files into `backend/sample_payloads/` and run:
  `node src/utils/process_payloads.js`
- Webhook endpoint: POST JSON to `/webhook` on your backend to insert/update messages.
