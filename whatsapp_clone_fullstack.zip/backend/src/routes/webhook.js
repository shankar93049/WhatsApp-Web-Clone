const express = require('express');
const router = express.Router();
const Message = require('../models/Message');

// Accept webhook payloads (demo)
router.post('/', async (req,res)=>{
  const payload = req.body;
  // naive handling: if payload contains message -> insert; if status -> update
  try {
    if (payload && payload.message) {
      const m = {
        message_id: payload.message.id || payload.id,
        meta_msg_id: payload.meta_msg_id || null,
        wa_id: payload.from || payload.to || (payload.sender && payload.sender.wa_id) || 'unknown',
        from: payload.from,
        to: payload.to,
        text: payload.message.text?.body || payload.message.body || null,
        media: payload.message.media || null,
        timestamp: payload.timestamp ? new Date(payload.timestamp*1000) : new Date(),
        raw_payload: payload
      };
      await Message.findOneAndUpdate({ message_id: m.message_id }, { $setOnInsert: m }, { upsert: true });
      const io = req.app.get('io'); if (io) io.emit('new_message', m);
      return res.json({ ok:true, inserted: true });
    }
    if (payload && payload.status) {
      const q = payload.id ? { message_id: payload.id } : (payload.meta_msg_id ? { meta_msg_id: payload.meta_msg_id } : null);
      if (q) {
        const doc = await Message.findOne(q);
        const status = payload.status;
        if (doc) {
          doc.status = status;
          doc.status_history = doc.status_history || [];
          doc.status_history.push({ status, at: new Date() });
          await doc.save();
          const io = req.app.get('io'); if (io) io.emit('status_update', { message_id: doc.message_id, status });
          return res.json({ ok:true, updated: true });
        } else {
          await Message.create({
            message_id: payload.id || undefined,
            meta_msg_id: payload.meta_msg_id,
            wa_id: payload.to || payload.from,
            status,
            status_history: [{ status, at: new Date() }],
            raw_payload: payload,
            timestamp: new Date()
          });
          return res.json({ ok:true, created_stub: true });
        }
      }
    }
    return res.status(400).json({ ok:false, reason:'unknown payload' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok:false, error: err.message });
  }
});

module.exports = router;
