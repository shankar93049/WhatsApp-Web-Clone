const express = require('express');
const router = express.Router();
const Message = require('../models/Message');

// list conversations
router.get('/conversations', async (req,res)=>{
  const agg = await Message.aggregate([
    { $sort: { timestamp: -1 } },
    { $group: {
        _id: "$wa_id",
        lastMessage: { $first: "$$ROOT" },
        countTotal: { $sum: 1 }
    }},
    { $project: { wa_id: "$_id", lastMessage: 1, countTotal: 1 }},
    { $sort: { "lastMessage.timestamp": -1 } }
  ]);
  res.json(agg);
});

// get messages for a conversation
router.get('/conversations/:wa_id/messages', async (req,res)=>{
  const { wa_id } = req.params;
  const msgs = await Message.find({ wa_id }).sort({ timestamp: 1 }).limit(1000);
  res.json(msgs);
});

// send (store) a new outgoing message
router.post('/conversations/:wa_id/messages', async (req,res)=>{
  const { wa_id } = req.params;
  const { text, from, to } = req.body;
  const msg = new Message({
    message_id: 'local-' + Date.now(),
    wa_id,
    from,
    to,
    direction: 'out',
    text,
    timestamp: new Date(),
    status: 'sent',
    status_history: [{ status: 'sent', at: new Date() }]
  });
  const saved = await msg.save();
  const io = req.app.get('io');
  if (io) io.emit('new_message', saved);
  res.json(saved);
});

module.exports = router;
