const mongoose = require('mongoose');
const MessageSchema = new mongoose.Schema({
  message_id: { type: String, index: true },
  meta_msg_id: { type: String, index: true },
  wa_id: { type: String, index: true },
  from: String,
  to: String,
  direction: { type: String, enum: ['in','out'], default: 'in' },
  text: String,
  media: Object,
  status: { type: String, enum: ['sent','delivered','read','unknown'], default: 'sent'},
  status_history: [{ status: String, at: Date }],
  timestamp: { type: Date },
  raw_payload: Object,
}, { timestamps: true });
module.exports = mongoose.model('Message', MessageSchema);
