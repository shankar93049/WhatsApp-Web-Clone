const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');
const Message = require('../models/Message');

async function main() {
  const folder = path.join(__dirname, '../../sample_payloads');
  const files = fs.existsSync(folder) ? fs.readdirSync(folder).filter(f=>f.endsWith('.json')) : [];
  if (!files.length) {
    console.log('No sample payloads found. Place JSON files into backend/sample_payloads/');
    process.exit(0);
  }
  for (const file of files) {
    const content = fs.readFileSync(path.join(folder, file), 'utf8');
    let payload;
    try { payload = JSON.parse(content); } catch(e){ console.warn('invalid json', file); continue; }
    if (payload.message) {
      const m = {
        message_id: payload.message.id || payload.id,
        meta_msg_id: payload.meta_msg_id || null,
        wa_id: payload.from || payload.to || 'unknown',
        from: payload.from,
        to: payload.to,
        text: payload.message.text?.body || payload.message.body || null,
        media: payload.message.media || null,
        timestamp: payload.timestamp ? new Date(payload.timestamp*1000) : new Date(),
        raw_payload: payload
      };
      await Message.findOneAndUpdate({ message_id: m.message_id }, { $setOnInsert: m }, { upsert: true });
      console.log('inserted', m.message_id);
    }
    if (payload.status) {
      const q = payload.id ? { message_id: payload.id } : (payload.meta_msg_id ? { meta_msg_id: payload.meta_msg_id } : null);
      const status = payload.status;
      if (q) {
        const doc = await Message.findOne(q);
        if (doc) {
          doc.status = status;
          doc.status_history = doc.status_history || [];
          doc.status_history.push({ status, at: new Date() });
          await doc.save();
          console.log('updated status', doc.message_id, status);
        } else {
          await Message.create({
            message_id: payload.id || undefined,
            meta_msg_id: payload.meta_msg_id,
            wa_id: payload.to || payload.from,
            status,
            status_history: [{ status, at: new Date() }],
            raw_payload: payload,
            timestamp: new Date()
          });
          console.log('created stub for status', payload.id || payload.meta_msg_id);
        }
      }
    }
  }
  process.exit(0);
}

if (require.main === module) {
  // connect to local mongo or env mongo
  const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/whatsapp';
  mongoose.connect(MONGO, { useNewUrlParser:true, useUnifiedTopology:true })
    .then(()=> main())
    .catch(err=> { console.error(err); process.exit(1); });
}
