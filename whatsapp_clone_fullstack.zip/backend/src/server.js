require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const cors = require('cors');
const path = require('path');

const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server, { cors: { origin: '*' }});

app.use(cors());
app.use(express.json());

const Message = require('./models/Message');

// simple health
app.get('/', (req,res)=> res.send({status:'ok'}));

// set io
app.set('io', io);

// routes
const conv = require('./routes/conversations');
const webhook = require('./routes/webhook');
app.use('/api', conv);
app.use('/webhook', webhook);

const PORT = process.env.PORT || 4000;
const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/whatsapp';

mongoose.connect(MONGO, { useNewUrlParser:true, useUnifiedTopology:true })
  .then(()=> {
    console.log('Mongo connected');
    server.listen(PORT, ()=> console.log('Server listening on', PORT));
  })
  .catch(err=> {
    console.error('Mongo connection error', err);
    server.listen(PORT, ()=> console.log('Server listening (no db) on', PORT));
  });

io.on('connection', socket => {
  console.log('socket connected', socket.id);
  socket.on('disconnect', ()=> console.log('socket disconnected', socket.id));
});
