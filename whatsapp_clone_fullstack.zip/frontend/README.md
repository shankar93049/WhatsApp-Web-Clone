# Frontend (Vite + React)
- Install: `npm install`
- Dev: `npm run dev`
- Remember to set `VITE_BACKEND_URL` in `.env` or use default `http://localhost:4000`
