import React, { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';

const BACKEND = import.meta.env.VITE_BACKEND_URL || 'http://localhost:4000';

export default function App(){
  const [conversations, setConversations] = useState([]);
  const [active, setActive] = useState(null);

  useEffect(()=> {
    fetch(BACKEND + '/api/conversations').then(r=>r.json()).then(setConversations).catch(()=>{});
  }, []);

  return (
    <div className="app">
      <Sidebar convs={conversations} onSelect={setActive} />
      <ChatWindow wa_id={active && active.wa_id} backend={BACKEND} />
    </div>
  )
}
