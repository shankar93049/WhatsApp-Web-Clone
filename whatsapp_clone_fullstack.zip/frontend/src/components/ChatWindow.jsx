import React, { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';

export default function ChatWindow({ wa_id, backend }){
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const socketRef = useRef();

  useEffect(()=> {
    socketRef.current = io(backend);
    socketRef.current.on('new_message', m => {
      if (!wa_id || m.wa_id === wa_id) setMessages(prev => [...prev, m]);
    });
    socketRef.current.on('status_update', s => {
      setMessages(prev => prev.map(m => m.message_id === s.message_id ? {...m, status: s.status} : m));
    });
    return ()=> socketRef.current.disconnect();
  }, [backend, wa_id]);

  useEffect(()=> {
    if (!wa_id) return;
    fetch(backend + '/api/conversations/' + wa_id + '/messages')
      .then(r=>r.json()).then(setMessages).catch(()=>setMessages([]));
  }, [wa_id, backend]);

  async function send(){
    if (!text.trim() || !wa_id) return;
    const res = await fetch(backend + '/api/conversations/' + wa_id + '/messages', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ text, from: 'me', to: wa_id })
    });
    const m = await res.json();
    setMessages(prev => [...prev, m]);
    setText('');
  }

  return (
    <div className="chat">
      <div style={{padding:12, borderBottom:'1px solid #eee'}}>{wa_id || 'Select a conversation'}</div>
      <div className="messages">
        {messages.map(msg=>(
          <div key={msg._id || msg.message_id} className={'message ' + (msg.direction === 'out' ? 'out' : 'in')}>
            <div>{msg.text}</div>
            <div style={{fontSize:11, color:'#666'}}>{new Date(msg.timestamp || msg.createdAt || Date.now()).toLocaleString()}</div>
          </div>
        ))}
      </div>
      <div className="inputBar">
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Type a message" />
        <button onClick={send}>Send</button>
      </div>
    </div>
  )
}
