import React from 'react';
export default function Sidebar({ convs=[], onSelect }){
  return (
    <div className="sidebar">
      <div style={{padding:12, borderBottom:'1px solid #eee'}}>WhatsApp Clone</div>
      {convs.map(c=>(
        <div key={c.wa_id} className="conv" onClick={()=>onSelect(c)}>
          <div><strong>{c.wa_id}</strong></div>
          <div className="meta">{c.lastMessage && c.lastMessage.text ? c.lastMessage.text : 'No messages'}</div>
        </div>
      ))}
    </div>
  )
}
