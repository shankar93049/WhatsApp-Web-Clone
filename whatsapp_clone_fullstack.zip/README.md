# WhatsApp-Web Clone - Starter (Full Stack)
This zipped starter contains a backend (Express + Mongoose) and frontend (Vite + React) skeleton
to process webhook payloads, store messages, and display a WhatsApp-like UI.

Steps:
1. Unzip and navigate to backend and frontend folders.
2. For backend:
   - Copy backend/.env.example -> backend/.env and set MONGO_URI
   - npm install
   - npm run dev
   - Optionally place sample payload JSON files in backend/sample_payloads/ then run:
     node src/utils/process_payloads.js
3. For frontend:
   - npm install
   - set VITE_BACKEND_URL if backend is remote
   - npm run dev

This is a starter; adapt styles, components, and add auth as needed.
